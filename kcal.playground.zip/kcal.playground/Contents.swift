/*
Q. 많이 먹고 적게 운동하여 칼로리(cal)를 소모하려고 합니다. 칼로리(cal)를 소모하는 데 걸리는 최소 시간(분)을 알려주세요.

조건1. 소모해야 할 총 칼로리는 totalCalorie로 선언되어 있습니다.
조건2. 킥복싱은 분당 500cal, 수영은 분당 300cal, 윗몸일으키기는 분당 100cal, 걷기는 분당 1cal를 소모한다고 가정합니다.
조건3. 칼로리는 항상 정수이며, 운동은 분 단위만 고려합니다. 예를 들어 소모해야할 총 칼로리가 299cal일 때 킥복싱과 수영을 하면 1분이 되기 전에 299cal을 모두 소모하게 되므로 킥복싱과 수영은 할 수 없습니다.

(출력결과: 킥복싱 n분, 수영 n분, 윗몸일으키기 n분, 걷기 n분 운동으로 총 n칼로리를 n분만에 모두 소모할 수 있습니다.)
*/

import Foundation

func question02() {
    //아래 주석을 해제하여 문제를 해결해주세요!
    let totalCalorie: Int = Int.random(in: 1000...10000)
    
    var calorie = totalCalorie
    let exersices = [500, 300, 100, 1]
    var minutes: [Int] = []
    var totalTime = 0
    
    for count in exersices {
        let time = calorie / count
        totalTime += time
        minutes.append(time)
        calorie = calorie - (time * count)
    }
    
    print("킥복싱 \(minutes[0])분, 수영 \(minutes[1])분, 윗몸일으키기 \(minutes[2])분, 걷기 \(minutes[3])분 총 \(totalCalorie), \(totalTime)분")
    
    
}
